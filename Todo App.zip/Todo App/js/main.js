//build a object to store vaule
var data = localStorage.getItem("todoList") ?
    JSON.parse(localStorage.getItem("todoList")) : {
        todo: [],
        completed: [],
        deleted: []
    };

console.log(data);

// Remove and complete icons in i format
var removeIcon = '<i class="far fa-trash-alt"></i>';
var completeIcon = '<i class="far fa-check-circle"></i>';

renderTodoList();


// user clicked on the add button
// If there is any text inside the item, add that text to the todo list
document.getElementById("add").addEventListener("click", function() {
    var value = document.getElementById("item").value;
    if (value) {
        addItem(value);
    }
});

document.getElementById("item").addEventListener("keydown", function(e) {
    var value = this.value;
    console.log(value);
    if (e.code === "Enter" && value) {
        addItem(value);
    }
});

function addItem(value) {
    addItemToDOM(value);
    document.getElementById("item").value = "";
    data.todo.push(value);
    dataObjectUpdated();
}

function renderTodoList() {
    if (!data.todo.length && !data.completed.length) return;

    for (var i = 0; i < data.todo.length; i++) {
        var value = data.todo[i];

        addItemToDOM(value);
    }
    for (var j = 0; j < data.completed.length; j++) {
        var value = data.completed[j];

        addItemToDOM(value, true);
    }
}

function dataObjectUpdated() {
    //local storage
    localStorage.setItem("todoList", JSON.stringify(data));
}

function removeItem() {
    var item = this.parentNode.parentNode;
    var parent = item.parentNode;
    var id = parent.id;
    var value = item.innerText;

    if (id === "todo") {
        data.todo.splice(data.todo.indexOf(value), 1);
        data.deleted.push(value);
    } else {
        data.completed.splice(data.todo.indexOf(value), 1);
        data.deleted.push(value);
    }

    dataObjectUpdated();
    parent.removeChild(item);
}

function completeItem() {
    var item = this.parentNode.parentNode;
    var parent = item.parentNode;
    var id = parent.id;
    var value = item.innerText;

    if (id === "todo") {
        data.todo.splice(data.todo.indexOf(value), 1);
        data.completed.push(value);

    } else {
        data.completed.splice(data.todo.indexOf(value), 1);
        data.todo.push(value);
    }
    dataObjectUpdated();

    // check if item should be added to the completed list to re-added to the todo list
    var target =
        id === "todo" ?
        document.getElementById("completed") :
        document.getElementById("todo");

    parent.removeChild(item);
    target.insertBefore(item, target.childNodes[0]);
}

// Adds new items to the todo list
function addItemToDOM(text, completed) {
    var list = completed ?
        document.getElementById("completed") :
        document.getElementById("todo");
    var item = document.createElement("li");
    item.innerText = text;

    var buttons = document.createElement("div");
    buttons.classList.add("buttons");

    var remove = document.createElement("button");
    remove.classList.add("remove");
    remove.innerHTML = removeIcon;

    //Add click event for removing item
    remove.addEventListener("click", removeItem);

    var complete = document.createElement("button");
    complete.classList.add("complete");
    complete.innerHTML = completeIcon;

    //Add click event for completing item
    complete.addEventListener("click", completeItem);

    buttons.appendChild(remove);
    buttons.appendChild(complete);
    item.appendChild(buttons);

    // let the newest item on top
    list.insertBefore(item, list.childNodes[0]);
}